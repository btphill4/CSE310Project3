./dijkstra network01.txt directed < input05.txt > output05.txt
