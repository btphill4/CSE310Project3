./dijkstra network02.txt undirected < input13.txt > output13.txt
