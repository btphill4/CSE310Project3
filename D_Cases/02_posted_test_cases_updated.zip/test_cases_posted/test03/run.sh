./dijkstra network01.txt directed < input03.txt > output03.txt
