./dijkstra network01.txt directed < input04.txt > output04.txt
