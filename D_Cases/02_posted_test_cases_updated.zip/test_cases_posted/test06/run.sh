./dijkstra network01.txt directed < input06.txt > output06.txt
