./dijkstra network01.txt directed < input07.txt > output07.txt
