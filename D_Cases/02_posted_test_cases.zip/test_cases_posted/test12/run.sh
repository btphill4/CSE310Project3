./dijksrta network02.txt undirected < input12.txt > output12.txt
