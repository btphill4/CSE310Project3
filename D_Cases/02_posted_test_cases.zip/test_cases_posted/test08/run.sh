./dijksrta network01.txt directed < input08.txt > output08.txt
