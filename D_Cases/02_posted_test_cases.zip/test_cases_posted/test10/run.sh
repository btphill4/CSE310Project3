./dijksrta network02.txt undirected < input10.txt > output10.txt
