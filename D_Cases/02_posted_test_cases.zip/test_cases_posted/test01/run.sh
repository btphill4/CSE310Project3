~/dijksrta network01.txt directed < input01.txt > output01.txt
