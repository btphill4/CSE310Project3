./dijksrta network02.txt undirected < input09.txt > output09.txt
