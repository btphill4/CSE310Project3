./dijksrta network01.txt directed < input02.txt > output02.txt
