./dijksrta network02.txt undirected < input11.txt > output11.txt
