./dijksrta network02.txt directed < input13.txt > output13.txt
