./dijksrta network02.txt undirected < input14.txt > output14.txt
